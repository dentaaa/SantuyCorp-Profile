# Midterm-WEBPRO-B
* _Anggara Yuda Pratama (05111840000008)_
* _Irsyadhani Dwi Shubhi (05111840000022)_
* _Brananda Denta Wira Pranata (05111840000143)_
----------------------------------------------------------------
This repo created for submission of Web Programming Lecture

## Mid Term
Article Forum Website using Framework Laravel (including homepage, register, login,  profile page, post page, comment page, and reset password page)

## How To Run On Localhost
- Run and open Apache on XAMPP or another app
- Make database laravel in PHPMyadmin
- Import SQL [file SQL](article.sql)
- Windows + R
- write ```cmd``` then Enter
- Write composer install
- Write composer update
- Write php artisan key:generate
- Write php artisan cache:clear
- Write php artisan config:clear
- Write php artisan migrate
- Write php artisan serve
- Write on your URL: http://localhost:8000

## Our Website
- Write on your website URL: http://forum-article823.000webhostapp.com/
